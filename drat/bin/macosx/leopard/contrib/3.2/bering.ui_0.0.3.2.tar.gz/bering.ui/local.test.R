library(bering.ui)
library(data.table)

############### Upload local data to Mongo ##########

#' @TODO generate a vector of column names
#' metadata save.as = "colnames"

symphony <- fread("/Users/ignat/Documents/Bering/Projects/BRAVE/Dataset/Symphony/symphony.csv")
setnames(symphony, old = colnames(symphony), new = gsub(x = colnames(symphony), pattern = "\\.", replacement = "_"))

data <- symphony[pcdDiabetes == "yes" & Other_UC_Sum != 1]
data$Other_UC_Sum <- as.factor(ifelse(data$Other_UC_Sum >0, "Case", "Control"))

data <- as.data.frame(unclass(data))
push(var = data, save.as = "symphony", db.name = "pipeline", collection.name = "data", host = "localhost")

################ Data plotting
args <- '{"vars": ["Age", "ChronicETGCount", "Risk_Ratio"], "by": "pcdDiabetes", "file_name": "sm", "db_name": "pipeline", "file_collection_name": "data", "host": "localhost", "exec": "exec.plot", "wf_id": "ABCD1234EFAB5678CDEF9012"}'

res <- pour(args)


args <- '{"vars": [], "by": "pcdDiabetes", "file_name": "sm", "db_name": "pipeline", "file_collection_name": "data", "host": "localhost", "exec": "exec.plot", "wf_id": "ABCD1234EFAB5678CDEF9012"}'

############### Build Model #########################

args <- '{"wf_id": "ABCD1234EFAB5678CDEF9012", "file_name": "diabetes", "db_name": "pipeline", "file_collection_name": "data", "host": "localhost", "exec": "exec.model", "rm_columns": [3, 4, 5, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,  24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153], "response": [11]}'

pour(args)


############## Visualise variable importance ########
args <- '{"vars": ["Case", "Control"], "by": [], "file_name": "ABCD1234EFAB5678CDEF9012_variableImportance.rds", "db_name": "pipeline", "file_collection_name": "data", "host": "localhost", "exec": "exec.plot", "wf_id": "ABCD1234EFAB5678CDEF9012"}'

s <- pour(args)
bering.d3::d3.write(jsonlite::fromJSON(s)$out, "imp.html")
