# Class definitions for workflow modules

#' flowModule class
#' @exportClass flowModule
setClass("flowModule",
        representation(id = "character",
                       inEdge = "ANY",
                       outEdge = "ANY",
                       exec = "ANY"),
        prototype(id = paste(sample(c(0:9, letters, LETTERS), 9, replace=TRUE), collapse=""),
                  inEdge = NULL,
                  outEdge = NULL,
                  exec = NULL)
        )
# TODO validity
#setValidity("flowModule", function(object) {
#msg <- NULL
#atgc <- grep("[^atcg]", sequences(object))
#if (length(atgc)>0)
#msg <- c(msg, "'sequences' must be a, t, c, or g")
#if (is.null(msg)) TRUE
#else msg + })

#' @export
setMethod("show", signature("flowModule"),
          function(object){
            title <- paste0(object@id, ": flowModule object\n")
            inEdges <- paste0("Incoming edges: ", length(object@inEdge), "\n")
            outEdges <- paste0("Outgoing edges: ", length(object@outEdge), "\n")
            slots <- paste0("Slots: \n      @", paste(slotNames(object), collapse ="\n      @"))
            cat(title, inEdges, outEdges, slots, "\n", sep = "")
  })

#' Execute the flowModule
#'
#' Execute the function contained in the the @exec slot using the @inEdge information
#'
#' @param module  a flowModule object with an incoming flowEdge
#'
#' @export
exec <- function(module){
  if (! is(module, "flowModule")) stop("Input is not a valid flowModule")

  do.call(module@exec, list(object = module))
}
