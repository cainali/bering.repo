#' @export
exec.loadData <- function(object){

############################# Executing inEdge arguments #######################
# Prep input parameters
arglist <- list(var = object@inEdge@args$file_name,
                collection.name = object@inEdge@args$file_collection_name,
                db.name = object@inEdge@db.name,
                host = object@inEdge@host)

# Fetch the data.frame
df <- tryCatch(do.call(pull, arglist),
                       error = function(cond){
                       message(paste0("Error in exec.importData. Cannot fetch data.frame ", object@inEdge@args$file_name, " from MongoDB."))
                       message("Original error message:")
                       message(cond)
                       cat("\n")
                       return(FALSE)})

# Associate df with this Workflow and push it again into MongoDB. save_as variable will be passed to the next step
save_as <- paste0(object@inEdge@wf.id, "_loadData.rds")

arglist <- list(var = df,
                save.as = save_as,
                db.name = object@outEdge@db.name,
                collection.name = object@inEdge@args$file_collection_name,
                host = object@outEdge@host)

push.df.success <- tryCatch(do.call(push, arglist),
                            error = function(cond){
                            message(paste0("Error in exec.importData. Cannot push ", save_as, " to MongoDB."))
                            message("Original error message:")
                            message(cond)
                            cat("\n")
                            return(FALSE)})

# Convert top 'head' rows to json
json <- df.toJSON(df)
json.name <- paste0(object@inEdge@wf.id, "_loadData", collapse = "")

# Prep output parameters
arglist <- list(obj = json,
                obj.name = json.name,
                db.name = object@outEdge@db.name,
                bson.collection.name = "json",
                host = object@outEdge@host
              )

# Push bson
push.json.success <- tryCatch(do.call(push.bson, arglist),
                        error = function(cond){
                        message("Error in exec.importData. Cannot push BSON to MongoDB.")
                        message("Original error message:")
                        message(cond)
                        cat("\n")
                        return(FALSE)})

success <- !is.null(df) & push.df.success & push.json.success

if (success){
  # Update workflow's step (sOutputs.file_name)
 update.bson.fields(oid=object@inEdge@wf.id,
                    criteria.field.names = c("wfSteps.sMethod"),
                    criteria.field.values=c("module_loadData"),
                    update.field.names=c("wfSteps.$.sOutputs.file_name"),
                    update.field.values=save_as, # This value is extracted by the following step
                    db.name = object@inEdge@db.name,
                    bson.collection.name = "workflows",
                    host = object@inEdge@host)

}

return(success)

}
