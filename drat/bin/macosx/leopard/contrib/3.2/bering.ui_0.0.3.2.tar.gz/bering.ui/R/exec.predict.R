#' @export

exec.predict <- function(object){

arglist <- list(var = object@inEdge@args$file_name,
                collection.name = object@inEdge@args$file_collection_name,
                db.name = object@inEdge@db.name,
                host = object@inEdge@host)

# Fetch the model
model <- tryCatch(do.call(pull, arglist),
                          error = function(cond){
                          message(paste0("Error in exec.predict. Cannot fetch model ", object@inEdge@args$file_name, " from MongoDB."))
                          message("Original error message:")
                          message(cond)
                          cat("\n")
                          return(FALSE)})

# Need to unserialize the model. It's a pain in the ass, but mongodb can't store C++ pointers
  if(class(model) == "MXFeedForwardModel"){
    model$symbol <- mxnet::mx.symbol.load.json(model$symbol)
    model$arg.params <- sapply(model$arg.params, mxnet::mx.nd.array)
    model$aux.params <- sapply(model$aux.params, mxnet::mx.nd.array)
}

# Fetch the testing dataset
arglist <- list(var = object@inEdge@args$new_data,
                collection.name = object@inEdge@args$file_collection_name,
                db.name = object@inEdge@db.name,
                host = object@inEdge@host)

test <- tryCatch(do.call(pull, arglist),
                          error = function(cond){
                          message(paste0("Error in exec.predict. Cannot fetch data.frame ", object@inEdge@args$new_data, " from MongoDB."))
                          message("Original error message:")
                          message(cond)
                          cat("\n")
                          return(FALSE)})

# Run predictions
y.hat <- ml.predict(model, test)

save_as <- paste0(object@inEdge@wf.id, "_predict.rds",  collapse = "")

# Save predictions to mongo
arglist <- list(var = y.hat,
                save.as = save_as,
                collection.name = object@inEdge@args$file_collection_name,
                db.name = object@inEdge@db.name,
                host = object@inEdge@host)

success <- tryCatch(do.call(push, arglist),
                            error = function(cond){
                            message(paste0("Error in exec.buildModel. Cannot push ", save_as, " to MongoDB."))
                            message("Original error message:")
                            message(cond)
                            cat("\n")
                            return(FALSE)})


if (success){
# Update workflow's step (sOutputs.file_name)
  update.bson.fields(oid=object@inEdge@wf.id,
  criteria.field.names = c("wfSteps.sMethod"),
  criteria.field.values=c("module_predict"),
  update.field.names=c("wfSteps.$.sOutputs.file_name"),
  update.field.values=save_as, # This value is extracted by the following step
  db.name = object@inEdge@db.name,
  bson.collection.name = "workflows",
  host = object@inEdge@host)
  }

return(success)
}
