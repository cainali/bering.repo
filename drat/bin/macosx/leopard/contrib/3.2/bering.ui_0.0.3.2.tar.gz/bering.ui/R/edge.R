#' The \code{flowEdge} class
#'
#' A unifying interface for passing information between computational modules
#'
#' @slot edge.id            Unique edge identifier. Object of class \code{"character"}.
#' @slot args               Arguments to be passed to module. Object of class \code{"list"}.
#' @slot wf.id              Workflow Identifier. Object of class \code{"character"}.
#' @slot db.name            Database name. Object of class \code{"character"}.
#' @slot collection.name    Collection name. Object of class \code{"character"}.
#' @slot host               Host name. Object of class \code{"character"}.
#'
#' @name flowEdge
#' @rdname flowEdge
#' @aliases flowEdge-class
#' @exportClass flowEdge
#' @author Ignat Drozdov
setClass("flowEdge",
        representation(id = "character",
                       args = "list",
                       wf.id = "character",
                       db.name = "character",
                       host = "character"),

        prototype(id = paste(sample(c(0:9, letters, LETTERS), 9, replace=TRUE), collapse=""),
                  args = NULL,
                  wf.id = NULL,
                  db.name = "pipeline",
                  host = "localhost")
        )
# TODO validity
#setValidity("flowEdge", function(object) {
#msg <- NULL
#atgc <- grep("[^atcg]", sequences(object))
#if (length(atgc)>0)
#msg <- c(msg, "'sequences' must be a, t, c, or g")
#if (is.null(msg)) TRUE
#else msg + })

#' @export
setMethod("show", signature("flowEdge"),
          function(object){
            title <- paste0(object@id, ": flowEdge object\n")
            slots <- paste0("Slots: \n      @", paste(slotNames(object), collapse ="\n      @"))
            cat(title, slots, "\n", sep = "")
  })
