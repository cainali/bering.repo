#' Push R workspace variable into MongoDB
#'
#' \code{push} saves an in-memory R variable into MongoDB as a Raw object
#'
#' @param var R object
#' @param save.as character file name which will be used in MongoDB.
#'                If NULL, deparsed name of var parameter will be used by default
#' @param db.name MongoDB database name
#' @param collection MongoDB collection name
#' @param host MongoDB database host address
#' @param ... extra arguments to be passed to the rmongodb::mongo.create() function
#'
#' @export
#' @import rmongodb

push <- function(var = NULL, save.as = NULL, db.name = "", collection.name = "", host = "localhost"){

  # If save.as argument is missing, cast var to string for storage into DB
  if ( is.null(save.as) ) save.as <- deparse(substitute(var))

  # Mongo Driver
  mongo <- mongo.create(db = db.name, host = host)
  if( !mongo.is.connected(mongo) ) stop(paste0("Cannot establish connection to ", host, collapse = ""))

  # GridFS file system driver
  gridfs <- mongo.gridfs.create(mongo, db = db.name, collection.name)

  # Check existance of the file in Mongo
  # TODO: Discuss actions to be taken if duplicate files exist in mongo. WARNING vs. ERROR
  f <- mongo.gridfs.find(gridfs, save.as)
  if ( !is.null(f) ) warning(paste0("File ", save.as, " already exists in ", db.name, ".", collection.name, collapse = ""))

  # Convert R object to RAW binary
  raw <- serialize(var, NULL)

  # Push to GRIDFS
  success <- mongo.gridfs.store(gridfs, raw , save.as)

  if(success) cat("File", save.as, "inserted to mongo\n")
  invisible(mongo.gridfs.destroy(gridfs))
  invisible(mongo.destroy(mongo))

  return(success)
}


#' Pull data from MongoDB into R workspace
#'
#' @param var string variable name to be pulled from MongoDB
#' @param db.name MongoDB database name
#' @param collection MongoDB collection name
#' @param host MongoDB database host address
#' @param ... extra arguments to be passed to the rmongodb::mongo.create function
#'
#' @export

pull <- function(var = NULL, db.name = "", collection.name = "", host = "localhost", ...){

  # TODO: Discuss how we support multiple files with the same name

  # Mongo Driver
  mongo <- mongo.create(db = db.name, host = host,...)
  if( !mongo.is.connected(mongo) ) stop(paste0("Cannot establish connection to ", host, collapse = ""))

  # GridFS file system driver
  gridfs <- mongo.gridfs.create(mongo, db = db.name, collection.name)

  # Fetch the grid file
  gf <- mongo.gridfs.find(gridfs, var)

  if( is.null(gf) ){
    stop( paste0("File ", var, " does not exists in ", db.name, ".", collection.name, collapse = "") )
    return(NULL)
  }

  # Read gridfile into memory
  r <- mongo.gridfile.read(gf, mongo.gridfile.get.length(gf))

  # Convert from binary to original data type
  res <- unserialize(r, NULL)

  cat("File", var, "pulled from mongo\n")

  invisible(mongo.gridfs.destroy(gridfs))
  invisible(mongo.gridfile.destroy(gf))
  invisible(mongo.destroy(mongo))

  return(res)
}

#' Push BSON
#'
#' @param obj Object to be upserted into MongoDB document collection
#' @param obj.name The name of the object to be upserted into MongoDB
#' @param db.name MongoDB database name
#' @param bson.collection.name MongoDB document collection name
#' @param host MongoDB host name
#' @export

push.bson <- function(obj, obj.name, db.name, bson.collection.name, host) {

  # Create BSON object to be upserted in MongoDB
  # BSON structure is {name: obj.name, data: obj}
  buf <- mongo.bson.buffer.create()
  mongo.bson.buffer.append(buf, "name", obj.name)
  mongo.bson.buffer.append(buf, "data", obj)
  objNew = mongo.bson.from.buffer(buf)

  # Create criteria for upsertion
  buf <- mongo.bson.buffer.create()
  mongo.bson.buffer.append(buf, "name", obj.name)
  criteria <- mongo.bson.from.buffer(buf)

  # Upsert BSON object into MongoDB
  cat("Pushing BSON object with name: ", obj.name, " into MongoDB\n", sep = "")

  success <-  FALSE
  # Establish connection to MongoDB
  mongo <- mongo.create(db = db.name, host = host)

  if (mongo.is.connected(mongo)) {

    # The name of the namespace for BSON documents in internal MongoDB
    ns <- paste0(db.name, ".", bson.collection.name, collapse = "")

    # Upsert BSON object in MongoDB based on criteria
    success <- mongo.update(mongo, ns, criteria, objNew, mongo.update.upsert)

    if ( !success )
      print(paste0("Could not insert a JSON object ", obj.name, " into ", ns, collapse = ""))
  }

  invisible(mongo.destroy(mongo))
  return(success)
}

#' Pull BSON
#'
#' @param obj.name The name of the object to be upserted into MongoDB
#' @param db.name MongoDB database name
#' @param bson.collection.name MongoDB document collection name
#' @param host MongoDB host name
#' @export

pull.bson <- function(obj.name, db.name, bson.collection.name, host) {
  # Create criteria
  buf <- mongo.bson.buffer.create()
  mongo.bson.buffer.append(buf, "name", obj.name)
  criteria <- mongo.bson.from.buffer(buf)

  # Find BSON object in MongoDB
  cat("\nPulling BSON object with name: ", obj.name, " from MongoDB\n", sep = "")

  # Establish connection to MongoDB
  mongo <- mongo.create(db = db.name, host = host)

  if (mongo.is.connected(mongo)) {

    # The name of the namespace for BSON documents in MongoDB
    ns <- paste0(db.name, ".", bson.collection.name, collapse = "")

    # Find BSON object in MongoDB based on criteria
    obj <- mongo.find.one(mongo, ns, criteria)

    if (is.null(obj))
      print(paste0("Could not find a BSON object with name: ", obj.name, " in ", ns, collapse = ""))

  }

  invisible(mongo.destroy(mongo))
  return(obj)
}

#' Update BSON
#'
#' @param oid Object ID in MongoDB
#' @param criteria.field.names The vector of keys of criteria object
#' @param criteria.field.values The vector of values of criteria object
#' @param update.field.names The vector of keys of update object
#' @param update.field.values The vector of values of update object
#' @param db.name MongoDB database name
#' @param bson.collection.name MongoDB document collection name
#' @param host MongoDB host name
#' @export
update.bson.fields <- function(oid, criteria.field.names, criteria.field.values, update.field.names, update.field.values, db.name, bson.collection.name, host) {

  # Create criteria for update
  buf <- mongo.bson.buffer.create()
  mongo.bson.buffer.append.oid(buf, "_id", mongo.oid.from.string(oid))
  for (i in 1:length(criteria.field.names)) {
    mongo.bson.buffer.append(buf, criteria.field.names[i], criteria.field.values[i])
  }
  criteria <- mongo.bson.from.buffer(buf)
  print(criteria)

  # Create BSON object to update specified fields in the selected document in MongoDB
  # BSON structure is {$set: {field.name: field.value}}
  buf <- mongo.bson.buffer.create()
  mongo.bson.buffer.start.object(buf, "$set")
  for (i in 1:length(update.field.names)) {
    mongo.bson.buffer.append(buf, update.field.names[i], update.field.values[i])
  }
  mongo.bson.buffer.finish.object(buf)
  objNew = mongo.bson.from.buffer(buf)
  print(objNew)

  # Update BSON document in MongoDB
  cat("\nUpdating BSON object with oid: ", oid, " in MongoDB\n", sep = "")

  success <-  FALSE
  # Establish connection to MongoDB
  mongo <- mongo.create(db = db.name, host = host)

  if (mongo.is.connected(mongo)) {

    # The name of the namespace for BSON documents in internal MongoDB
    ns <- paste0(db.name, ".", bson.collection.name, collapse = "")

    # Update BSON document in MongoDB based on criteria
    success <- mongo.update(mongo, ns, criteria, objNew, mongo.update.basic)

    if ( !success )
      print(paste0("Could not update a BSON document ", oid, " in ", ns, collapse = ""))
  }

  invisible(mongo.destroy(mongo))
  return(success)
}
