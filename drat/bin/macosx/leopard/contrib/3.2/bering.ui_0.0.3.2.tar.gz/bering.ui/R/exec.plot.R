#' Visualise user-selected data
#'
#' @param object  module object
#' @import bering.d3
#' @export


exec.plot <- function(object){
  vars <- object@inEdge@args$vars
  by <- object@inEdge@args$by

  if(length(vars)==0)
    stop("Error in exec.plot. Please specify at least one column for exploration.")

  if(length(by) == 0) by <- NULL

  data <- pull(var = object@inEdge@args$file_name, db.name = object@inEdge@db.name, collection.name = object@inEdge@args$file_collection_name, host = object@inEdge@host)

  df <- condense(vars, by = by, data = data)

  g <- d3.autoplot(df, as.d3 = T)

  return(g)
}
