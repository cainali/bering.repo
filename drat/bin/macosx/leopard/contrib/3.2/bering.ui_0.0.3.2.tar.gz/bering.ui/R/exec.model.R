#' @export
#' @import bering.ml
exec.model<- function(object){

# Fetch dataset from MongoDB

arglist <- list(var = object@inEdge@args$file_name,
                collection.name = object@inEdge@args$file_collection_name,
                db.name = object@inEdge@db.name,
                host = object@inEdge@host)


dFrame <- tryCatch(do.call(pull, arglist),
                         error = function(cond){
                           message(paste0("Error in exec.model. Cannot fetch data.frame ", object@inEdge@args$file_name, " from MongoDB."))
                           message("Original error message:")
                           message(cond)
                           cat("\n")
                           return(FALSE)})

# Create training and testing partitions. Use 75 percent of data as training
set.seed(123)
trainIndex <- sample(x = 1:nrow(dFrame), size = round(0.75 * nrow(dFrame)), replace = FALSE)

train <- dFrame[trainIndex, ]
test <- dFrame[-trainIndex, ]

# Assign response and predictors variables
response <- object@inEdge@args$response
predictors <- colnames(dFrame)[-c(object@inEdge@args$rm_columns, response)]

# Compute variable importances
importance <- ml.varimp(x = dFrame[,predictors], y = dFrame[,response])

imp.summary <- apply(importance[,-1], 1, var)
importance <- importance[imp.summary >= summary(imp.summary)[5],]
importance$features <- factor(importance$features, levels = unique(importance$features))

save.as <- paste0(object@inEdge@wf.id, "_variableImportance.rds",  collapse = "")

arglist <- list(var = importance,
                save.as = save.as,
                db.name = object@outEdge@db.name,
                collection.name = object@inEdge@args$file_collection_name,
                host = object@outEdge@host)

save.importance.json <- tryCatch(do.call(push, arglist),
                            error = function(cond){
                            message(paste0("Error in exec.buildModel. Cannot push ", save.as, " to MongoDB."))
                            message("Original error message:")
                            message(cond)
                            cat("\n")
                            return(FALSE)})


# Train a deep learning model using default parameters
arglist <- list(response = response,
                predictors = predictors,
                training.frame = train)

model <- tryCatch(do.call(ml.deeplearning, arglist),
                          error = function(cond){
                          message("Error in exec.buildModel. Cannot train the deep learning model.")
                          message("Original error message:")
                          message(cond)
                          cat("\n")
                          return(FALSE)})

# Must convert to R-native objects prior to serialization
mongo.model <- model
mongo.model$symbol <- mongo.model$symbol$as.json()
mongo.model$arg.params <- sapply(mongo.model$arg.params, as.array)
mongo.model$aux.params <- sapply(mongo.model$aux.params, as.array)

# Save the built model into Mongo DB
save.as <- paste0(object@inEdge@wf.id, "_buildModel.rds",  collapse = "")
arglist <- list(var = mongo.model,
                save.as = save.as,
                db.name = object@outEdge@db.name,
                collection.name = object@inEdge@args$file_collection_name,
                host = object@outEdge@host)

save.model <- tryCatch(do.call(push, arglist),
                            error = function(cond){
                            message(paste0("Error in exec.buildModel. Cannot push ", save.as, " to MongoDB."))
                            message("Original error message:")
                            message(cond)
                            cat("\n")
                            return(FALSE)})

# Make predictions on testing set
yh <- ml.predict(model, test)

# Calculate model performance
confusion.matrix <- table(yh$response, test[,response])

# True Positives
A <- confusion.matrix[1,1]

# False Positives
B <- confusion.matrix[1,2]

# True Negatives
C <- confusion.matrix[2,1]

# False Negatives
D <- confusion.matrix[2,2]

performance <- list()

performance$PositiveClass <- colnames(confusion.matrix)[1]
performance$sensitivity <- A/(A+C)
performance$specificity <- D/(B+D)
performance$prevalence <- (A+C)/(A+B+C+D)
performance$PosPredVal <- (performance$sensitivity * performance$prevalence)/((performance$sensitivity*performance$prevalence) + ((1-performance$specificity)*(1-performance$prevalence)))
performance$NegPredVal <- (performance$specificity * (1-performance$prevalence))/(((1-performance$sensitivity)*performance$prevalence) + ((performance$specificity)*(1-performance$prevalence)))
performance$accuracy <- (performance$sensitivity+performance$specificity)/2

# Save model performance to MongoDB
save.as <- paste0(object@inEdge@wf.id, "_modelPerformance.json",  collapse = "")
arglist <- list(var = jsonlite::toJSON(performance),
                save.as = save.as,
                db.name = object@outEdge@db.name,
                collection.name = object@inEdge@args$file_collection_name,
                host = object@outEdge@host)

save.performance.json <- tryCatch(do.call(push, arglist),
                            error = function(cond){
                            message(paste0("Error in exec.buildModel. Cannot push ", save.as, " to MongoDB."))
                            message("Original error message:")
                            message(cond)
                            cat("\n")
                            return(FALSE)})


if (class(dFrame) != "logical" & class(model) != "logical" & save.model & save.performance.json & save.importance.json){

# Update workflow's step (sOutputs.file_name)
  update.bson.fields(oid=object@inEdge@wf.id,
                     criteria.field.names = c("wfSteps.sMethod"),
                     criteria.field.values=c("module_buildData"),
                     update.field.names=c("wfSteps.$.sOutputs.file_name"),
                     update.field.values=save.as, # IS THIS NEEDED??? This value is extracted by the following step.
                     db.name = object@inEdge@db.name,
                     bson.collection.name = "workflows",
                     host = object@inEdge@host)
}

return(class(dFrame) != "logical" & class(model) != "logical" & save.model & save.performance.json & save.importance.json)
}
