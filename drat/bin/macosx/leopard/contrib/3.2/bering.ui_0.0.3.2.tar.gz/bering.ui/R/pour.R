#' Execute a module using the incoming and outgoing Flows
#'
#' @param args  JSON or list argument with
#' @export
#' @importFrom jsonlite fromJSON


pour <- function(args){
  if (! is(args, "list"))
    args <- fromJSON(args)

  envir.args <- c("db_name", "host", "wf_id")
  module.args <- c("exec")
  inEdge.args <- setdiff(names(args), c(envir.args, module.args))
  outEdge.args <- setdiff(args, c(module.args, inEdge.args))


  inEdge <- new("flowEdge",
                args = args[inEdge.args],
                wf.id = args$wf_id,
                db.name = args$db_name,
                host = args$host)

  outEdge <- new("flowEdge",
                args = outEdge.args,
                wf.id = args$wf_id,
                db.name = args$db_name,
                host = args$host)

  module <- new("flowModule",
                inEdge = inEdge,
                outEdge = outEdge,
                exec = get(args$exec))

  msg <- capture.output(output <- tryCatch(exec(module),
                error = function(cond){
                print(paste0("Error in pouring ", args$exec))
                print("Original error message:")
                print(cond)
                cat("\n")
                return(FALSE)}
          ))

  res <- jsonlite::toJSON(list(out = paste(output, collapse="\n"), error = paste(msg, collapse = "\n")))

  return(res)
}
