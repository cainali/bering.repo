library(RSclient)

c <- RS.connect()

RS.eval(c, library(bering.ui))

# Set working directory to a location where iris.csv dataset is located
RS.eval(c, setwd("~/Documents/Bering/rgit/bering.ui/"))

RS.eval(c, wf.id <- 987)
RS.eval(c, db.name = "brave")
RS.eval(c, data.collection.name = "data")
RS.eval(c, json.collection.name = "json")
RS.eval(c, model.collection.name = "model")
RS.eval(c, data.name <- "iris")


RS.eval(c, module.importData("iris.csv", save.as = data.name, db.name = db.name, data.collection.name = data.collection.name, json.collection.name = json.collection.name, wf.id = wf.id))

RS.eval(c, step2 <- module.processData(mongo.obj.name = step1$file.name, save.to.mongo = TRUE, db.name = db.name, data.collection.name = data.collection.name))

RS.eval(c, arg.list <- list(learning.rate = 0.01, hidden_node = 5, momentum = 0.9, array.batch.size = 3))

RS.eval(c, step3 <- module.buildModel(model.name = "mlp", predictors = c("Sepal_Length", "Sepal_Width", "Petal_Length", "Petal_Width"), response = "Species", mongo.obj.name = step2$file.name, arg.list = arg.list, save.to.mongo = TRUE, db.name = db.name, data.collection.name = data.collection.name, model.collection.name = model.collection.name))

RS.eval(c, step4 <- module.predict(mongo.model = step3$file.name, mongo.newdata = step2$file.name, db.name = db.name, data.collection.name = data.collection.name, model.collection.name = model.collection.name))

RS.close(c)
