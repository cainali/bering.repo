#' Import a CSV file
#
#' Import a .CSV file into R workspace. Function automatically handles column types in a way
#' that is appropriate for machine learning in R.
#'
#' @param input string path to .csv file
#' @param ... additional parameters passed to data.table::fread function
#'
#' @export
#' @importFrom data.table fread setnames

ml.read <- function(input = "", ...){
  file <- fread(input,...)
  proper.names <- make.names(colnames(file), allow_ = TRUE)
  proper.names <- gsub(x = proper.names, pattern = "\\.", replacement = "_")

  setnames(file, colnames(file), proper.names)

  # Convert characters to factors
  #as.data.frame(unclass(file))

  return(file)

}
