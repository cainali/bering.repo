#' Calculate the ROC curve
#'
#' @param probabilities   A numeric vector of predicted class probabilities
#' @param labels          A factor vector of actual class labels
#' @param positive        Character label of a positive observation
#' @export

ml.roc <- function(probabilities, labels, positive, n = 100){

labels <- labels == positive

tpr <- function(probabilities, labels, threshold) {
    sum( (probabilities >= threshold) & (labels == TRUE) ) / sum(labels == TRUE)
}

fpr <- function(probabilities, labels, threshold) {
    sum((probabilities >= threshold) & (labels == FALSE)) / sum(labels == FALSE)
}

roc <- data.frame(threshold = seq(0,1,length.out=n), tpr=NA, fpr=NA)

roc$tpr <- sapply(roc$threshold, function(th) tpr(probabilities, labels, threshold = th))
roc$fpr <- sapply(roc$threshold, function(th) fpr(probabilities, labels, threshold = th))

return(roc)

}
