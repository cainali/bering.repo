# bering.ml
R package for distributed data analysis and machine learning

## Installation of pre-requisites
We use the __data.table__ package to import and pre-process large datasets.

```r
install.packages(data.table)
```

MXNET package is used to engineer deep learning architectures. Follow platform-specific instructions on [the MXNET website](http://mxnet.readthedocs.org/en/latest/)

## bering.ml installation
```r
devtools::install_git("https://github.com/idroz/bering.ml")
```
