#' Calculation of filter-based variable importance
#'
#' @param model     A machine learning model
#' @export
ml.varimp <- function(model){

type <- class(model)

switch(type,
  ranger = {
    imp <- model$variable.importance
    features <- names(imp)
    ix <- order(imp, decreasing = TRUE)

    res <- data.frame(features = features[ix], importance = imp[ix])
    res$importance <- res$importance/max(res$importance)
  }
  )

#x <- data.matrix(x)

#positive <- classLevels <- levels(y)

#k <- length(classLevels)
#if (is.factor(y)){
#  outStat <- matrix(nrow = ncol(x), ncol = k)

#  for(i in 1:k){
#    pos <- positive[i]
#    outStat[,i] <- apply(x, 2, rocPerCol, y, pos)
#  }

#  colnames(outStat) <- classLevels

#} else {
#  outStat <- rep(0, ncol(x))
#  zv <- apply(x, 2, var) == 0

#  paraFoo <- function(data, y) abs(coef(summary(lm(y ~ data)))[2, "t value"])
#
#  imp <- apply(x[,!zv], 2, paraFoo, y = y)
#  outStat[!zv] <- imp

#  ix <- order(outStat, decreasing = TRUE)
#  outStat <- data.frame(Overall = outStat[ix])
#  outStat$features <- colnames(x)[ix]
#}

#res <- data.frame(features = colnames(x), outStat)
return(res)
}

rocPerCol <- function(dat, cls, positive) {
  roc <- ml.roc(dat/max(dat), cls, positive, n = 10)
  ml.auc(roc$fpr, roc$tpr)
}
