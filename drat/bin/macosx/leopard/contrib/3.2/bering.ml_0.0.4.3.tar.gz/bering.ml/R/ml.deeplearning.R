#' Train a deep learning model
#'
#' @param predictors        the predictor labels.
#' @param response          the response label.
#' @param training.frame    training data.frame
#'
#' @import h2o
#' @export

ml.deeplearning <- function(predictors, response, training.frame){

h2o.init(nthreads = -1)

balance_classes = TRUE

hidden <- rep(5 * ncol(training.frame), 2)

train.hex <- as.h2o(x = training.frame[,c(predictors, response)], "train.hex")
#test.hex <- as.h2o(x = validation.frame[,c(predictors, response)], "test.hex")

model <- h2o.deeplearning(x = predictors, y = response, training_frame = train.hex,
                          hidden = hidden, stopping_rounds = 1, stopping_metric="misclassification", stopping_tolerance=0.00001,
                          overwrite_with_best_model = TRUE, balance_classes = balance_classes,
                          variable_importances = TRUE)

h2o.shutdown(prompt = FALSE)
return(model)
}
