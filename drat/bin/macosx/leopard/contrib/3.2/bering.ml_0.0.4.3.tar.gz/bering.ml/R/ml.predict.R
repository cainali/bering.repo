#' Generalised prediction
#'
#' @param model     machine learning model
#' @param newdata   data.frame to be predicted
#' @import randomForest
#'
#' @export

ml.predict <- function(model, newdata){

type <- class(model)
# Predict using a randomForest model
switch(type,
  ranger = {
    yh <- predict(model, newdata)

    if(!is.null(dim(yh$predictions))){
      labels <- colnames(yh$predictions)[max.col(yh$predictions)]
      prediction <- cbind(as.data.frame(yh$predictions), labels)
      colnames(prediction) <- c(as.character(colnames(yh$predictions)), "response")
    } else{
      prediction <- yh$predictions
    }

  }
)

return(prediction)

}
