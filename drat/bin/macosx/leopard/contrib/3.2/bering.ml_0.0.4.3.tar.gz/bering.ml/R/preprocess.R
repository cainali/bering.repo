# internal functions for balancing an unballanced dataset

#' ROSE up-sampling algorithm
#' @param X input dataset
#' @param y response variables
#' @param p up-sampling fraction
#' @export

roseSample <- function(N, p, y, X, hmult.majo = 1, hmult.mino = 1) {
  class.freq <- table(y)
  classx <- apply(X, 2, class)
  classy <- class(y)
  d <- ncol(X)
  n <- length(y)

  # variables: must be numeric, integer or factor
	if( any( is.na( pmatch(classx, c( "numeric","integer","factor", "character"), duplicates.ok = TRUE ) ) ) )
			stop("The current implementation of ROSE handles only continuous and categorical variables.\n")

	if( any(class.freq < 2) )
			stop("ROSE needs at least two majority and two minority class examples.\n")

	if( missing(N) )
			N <- n

  majoY  <- levels(y)[which.max(class.freq)]
  minoY  <- levels(y)[which.min(class.freq)]

  n <- length(y)

  #identify the majority and minority class examples
  ind.mino <- which( y == minoY )
  ind.majo <- which( y == majoY )

    	#n.majo <- n.majo.new <- sum(y == majoY)
    	#n.mino <- n-n.majo

	#number of new minority class examples
	n.mino.new <- sum(rbinom(N, 1, p))
	#number of new majority class examples
	n.majo.new <- N-n.mino.new

	id.majo.new <- sample(ind.majo, n.majo.new, replace=TRUE)
	id.mino.new <- sample(ind.mino, n.mino.new, replace=TRUE)


	id.num  <- which(classx=="numeric" | classx=="integer")
	d.num   <- d-length( which(classx %in% c("factor", "character")) )

	#create  X
	Xnew <- data.frame(X[c(id.majo.new, id.mino.new),])
		if(d.num > 0)
		{
			 Xnew[1:n.majo.new, id.num] <- rose.real(X[,id.num], hmult=hmult.majo, n=length(ind.majo), q=d.num, ids.class=ind.majo, ids.generation=id.majo.new)
			 Xnew[(n.majo.new+1):N, id.num] <- rose.real(X[,id.num], hmult=hmult.mino, n=length(ind.mino), q=d.num, ids.class=ind.mino, ids.generation=id.mino.new)
		}

	#create  y
		if( classy%in%c("character", "integer", "numeric") )
			ynew <- as.vector( c(rep(majoY, n.majo.new), rep(minoY, n.mino.new)), mode=classy )
		if( classy=="factor" )
			ynew <- factor( c(rep(majoY, n.majo.new), rep(minoY, n.mino.new)), levels=c(majoY, minoY) )

	data.out <- data.frame(ynew, Xnew)
	rownames(data.out) <- 1:N

	list(data = Xnew, y=ynew)
}

rose.real <- function(X, hmult=1, n, q = NCOL(X), ids.class, ids.generation)
{
	X <- data.matrix(X)
	n.new <- length(ids.generation)
	cons.kernel <- (4/((q+2)*n))^(1/(q+4))

		if(q!=1)
			H <- hmult*cons.kernel*diag(apply(X[ids.class,], 2, sd), q)
		else
			H <- hmult*cons.kernel*sd(X[ids.class,])

	Xnew.num <- matrix(rnorm(n.new*q), n.new, q)%*%H
	Xnew.num <- data.matrix(Xnew.num + X[ids.generation,])
	Xnew.num
}

overSample <- function(X, y, p, yname){
  class.freq <- table(y)
  classy <- class(y)
  #identify which is the label associated to the majority and minority classes
	majoY  <- levels(y)[which.max(class.freq)]
	minoY  <- levels(y)[which.min(class.freq)]

  n <- length(y)

	#identify the majority and minority class examples
	ind.mino <- which( y == minoY )
	ind.majo <- which( y == majoY )

	n.majo <- n.majo.new <- sum(y == majoY)
	n.mino <- n-n.majo

	#theoretical n.mino
	n.mino <- round( p*n.majo/(1-p) )
	#estimated n.mino
	n.mino.new <- sum( rbinom(n.mino+n.majo, 1, p) )
	#final sample size
  N <- n.majo + n.mino.new

	id.majo.new <- ind.majo
	id.mino.new <- sample(ind.mino, n.mino.new, replace=TRUE)

	#create X
	Xnew <- data.frame(X[c(id.majo.new, id.mino.new),])
	#create  y
	if( classy%in%c("character", "integer", "numeric") )
    ynew <- as.vector( c(rep(majoY, n.majo.new), rep(minoY, n.mino.new)), mode=classy )

  if( classy=="factor" )
    ynew <- factor( c(rep(majoY, n.majo.new), rep(minoY, n.mino.new)), levels=c(majoY, minoY) )

	data.out <- data.frame(ynew, Xnew)

	rownames(data.out) <- 1:N

	list(data = Xnew, y= ynew)
}
