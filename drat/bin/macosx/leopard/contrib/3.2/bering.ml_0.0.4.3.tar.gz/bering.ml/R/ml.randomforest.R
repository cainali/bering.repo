#' Train a deep learning model
#'
#' @param predictors        the predictor labels.
#' @param response          the response label.
#' @param training.frame    training data.frame
#' @param auto.tune         logical
#' @param num.trees         integer
#' @param mtry              integer
#' @param ...               additional arguments to ranger function
#'
#' @import ranger
#' @export

ml.randomforest <- function(predictors, response, training.frame, auto.tune = FALSE, num.trees = 1000, mtry = floor(sqrt(length(predictors))), ...){

  x <- training.frame[,predictors]
  y <- training.frame[,response]

  classwt <- NULL
  if(is.factor(y))
  {
      type <- "classification"
      wt <- 10^(1-table(y)/max(table(y)))
      classwt <- wt[match(y, names(wt))]
  }

  if(is.numeric(y))
      type <- "regression"

  if(type == "classification"){

    if(auto.tune){
        default.mtry <- floor(sqrt(length(predictors)))
        mtry.grid <- expand.grid(mtry = c(floor(0.5 * default.mtry), default.mtry, floor(2 * default.mtry)), trees = num.trees)
        oob.error <- vector()

        for(n in 1:nrow(mtry.grid)){
          cat(paste0("Tuning step ", n, "/", nrow(mtry.grid)))
          rf <- ranger(dependent.variable.name = response, data = training.frame[,c(response, predictors)], probability = TRUE, case.weights = classwt, num.trees = num.trees, mtry = mtry.grid[n,"mtry"], ...)

          oob.error[n] <- rf$prediction.error
          cat(paste0(" | OOB error = ", oob.error[n], " | mtry = ", mtry.grid[n,"mtry"]), "\n")
        }

        mtry <- mtry.grid[which.min(oob.error), "mtry"]
    }

    model <- ranger(dependent.variable.name = response, data = training.frame[,c(response, predictors)], importance = "impurity", case.weights = classwt, write.forest = TRUE, probability = TRUE, num.trees = num.trees, mtry = mtry, ...)

  }

  if(type == "regression")
  {
    model <- ranger(dependent.variable.name = response, data = training.frame[,c(response, predictors)], importance = "impurity", case.weights = classwt, write.forest = TRUE, probability = FALSE, num.trees = num.trees, ...)
  }

  return(model)

}
