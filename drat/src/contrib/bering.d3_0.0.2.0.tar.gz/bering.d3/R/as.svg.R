#' Convert ggplot2 object to SVG
#' @param g       ggplot2 object
#' @param zoom    logical enabling zoom
#' @param width   image width
#' @param height  image height
#' @export

as.svg <- function(g, zoom = FALSE, width = NULL, height = NULL){

  col.class <- sapply(g$data, class)

  # All rownames need to be removed to create a suitable JSON file
  rownames(g$data) <- NULL

    # Export graph as SVG
    file <- tempfile()
    svg.id <- uuid.gen()

    eval(substitute(gridsvg(name=file, addClasses = TRUE, rootAttrs=list(width=width, height=height, viewBox = "0 0 575 700"), prefix = svg.id)))
    print(g)
    gridSVG::dev.off()

    g.svg <- xmlParse(file)
    unlink(file)

    f <- textConnection("res", "w")

    cat(saveXML(g.svg), "\n", file = f)

    close(f)

    return(res)
}
