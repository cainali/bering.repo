#' Condense a large data.frame
#'
#' Use automated data recognition to create a summary of large data.table variables
#'
#' @param vars  Character vector
#' @param by    Character value
#' @param data  data.table object
#' @import data.table
#' @export

condense <- function(vars, by = NULL, data){

  if(!is.data.table(data)) data <- as.data.table(data)

  # Filter the data.table using vars and by
  sub.data <- data[,unique(c(vars, by)), with = FALSE]

  # Determine plot structure of the filtered data.table
  col.class <- sapply(sub.data, class)

  vars.factor <- setdiff(names(col.class)[col.class %in% c("character", "factor")], by)
  if(length(vars.factor) == 0) vars.factor <- NULL

  vars.num <- setdiff(names(col.class)[col.class %in% c("numeric", "integer")], by)
  if(length(vars.num) == 0) vars.num <- NULL


######################################

  if( is.null(by) ){
    res <- sub.data

    if( (length(vars) == 1 | length(vars) > 2) & (length(vars.factor) == 0)){
      plot.class <- "d3.histogram"
    } else if( length(vars.num) == 2){
      plot.class <- "d3.xyplot"
    } else if ( (length(vars.num) == 0) & (length(vars.factor) == 1)){
      plot.class <- "d3.piechart"
    } else if ( (length(vars.num > 2)) & length(vars.factor) >= 1){
      by <- vars.factor
      setkeyv(sub.data, cols =  vars.factor)
      res <- res[, .summary(.SD), by=by, .SDcols=setdiff(colnames(sub.data), by)]
      plot.class <- "d3.magplot"
    } else {
      stop("C1: Cannot generate a meaningful plot from input parameters.")
    }
  } else {

    if(!is.null(vars.factor) & is.null(vars.num))
      stop("C2: Grouping categorical values does not yield quantitative results.")

    # Discretise the by column if it's numeric
    if( any(col.class[by] %in% c("integer", "numeric")) ){

      cols <- by[col.class[by] %in% c("integer", "numeric")]
      sub.data[, eval(cols) := .cut(sub.data[, cols, with = FALSE], method = "frequency", categories = round(nrow(sub.data)^(1/5))) ]
    }

    # Set key to facilitate query of the data.table
    setkeyv(sub.data, cols =  by)

    res <- sub.data[, .summary(.SD), by=by, .SDcols=setdiff(vars.num, by)]
    na.mask <- apply(res, 2, is.na)
    res[na.mask] <- 0
    plot.class <- "d3.magplot"


  }

  return(structure(list(.data = res, vars = vars, by = by), class = plot.class))
}

.cut <- function(dt, method, categories){
  sapply(dt, discretize, method = method, categories = categories)
}

.summary <- function(x) {
    mm <- colMeans(x, na.rm = TRUE)
    ss=sapply(x, sd, na.rm = TRUE)
    list(var=names(x), mean=mm, sd=ss)
}
