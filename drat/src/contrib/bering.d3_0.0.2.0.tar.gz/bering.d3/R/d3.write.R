#' Export a d3 ggplot object to file
#' @param obj   d3 object
#' @param file  export file name
#' @export

d3.write <- function(obj, file){
  fileConn<-file(file)
  writeLines(obj, fileConn)
  close(fileConn)
}
