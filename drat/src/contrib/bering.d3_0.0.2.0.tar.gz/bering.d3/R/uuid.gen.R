#' Generate a random UUID
#'
#' Version 4 UUIDs have the form:
#'    xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
#'    where x is any hexadecimal digit and
#'    y is one of 8, 9, A, or B
#'    f47ac10b-58cc-4372-a567-0e02b2c3d479
#'
#' @param uppercase   logical
#' @export

uuid.gen <- function(uppercase=FALSE) {

  hex_digits <- c(as.character(0:9), letters[1:6])
  hex_digits <- if (uppercase) toupper(hex_digits) else hex_digits

  y_digits <- hex_digits[9:12]

  uuid <- paste(
    paste0(sample(hex_digits, 8), collapse=''),
    paste0(sample(hex_digits, 4), collapse=''),
    paste0('4', sample(hex_digits, 3), collapse=''),
    paste0(sample(y_digits,1),
           sample(hex_digits, 3),
           collapse=''),
    paste0(sample(hex_digits, 12), collapse=''),
    sep='')

  # For D3, ID must bering with a letter. Therefore appending bering_
  paste0("bering_", uuid, "_", collapse = "")
}
