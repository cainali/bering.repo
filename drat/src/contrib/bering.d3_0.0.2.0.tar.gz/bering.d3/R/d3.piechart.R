#' D3-enabled bar plot
#'
#' @param g       ggplot2 object
#' @param zoom    logical enabling zoom
#' @param width   image width
#' @param height  image height
#' @export

d3.piechart <- function(g, zoom = FALSE, width = 9, height = 5){

  # All rownames need to be removed to create a suitable JSON file
  rownames(g$data) <- NULL

    # Export graph as SVG
    file <- tempfile()
    svg.id <- uuid.gen()

    eval(substitute(gridsvg(name=file, addClasses = TRUE, width=width, height=height, prefix = svg.id)))
    print(g)
    gridSVG::dev.off()

    g.svg <- xmlParse(file)
    unlink(file)

    f <- textConnection("res", "w")

    cat(saveXML(g.svg), "\n", file = f)

    close(f)

    return(res)
}
