#' Automated ggplot
#'
#' Automatically determines the type of ggplot to create using data.frame structure
#'
#' @param object  condense function object
#' @param as.d3   boolean value
#' @param ...     additional arguments to be supplied to the d3 helper functions
#' @export

d3.autoplot <- function(object, as.d3 = FALSE, ...){

bering.colours <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
bering.theme <- theme(legend.title=element_blank(), aspect.ratio = 2 / (1 + sqrt(5)) )

data <- as.data.frame(unclass(object$.data))
vars.numeric <- colnames(data)[sapply(data, class) %in% c("numeric", "integer")]
vars.factor <- colnames(data)[sapply(data, class) %in% c("factor", "character")]



# Scatterplot
if (class(object) == "d3.xyplot"){
  if(length(vars.factor) == 0) vars.factor <- NULL

  data.melt <- reshape2::melt(data, id.vars = vars.numeric)

  if( sum(c("variable", "value") %in% colnames(data.melt)) != 2){
    data.melt$value <- data.melt$variable <- rep(paste0(vars.numeric, collapse = " vs. "), nrow(data.melt))
    theme <- theme(legend.position="none")
  }

  if(nrow(data) < 1000)
    g <- ggplot(data.melt, aes_string(x = vars.numeric[1], y = vars.numeric[2], col = "value")) + geom_point() + stat_smooth(colour="black", fill = "grey") +  ggthemes::theme_hc() + facet_wrap(~variable) + scale_color_manual(values = bering.colours) + bering.theme

  if(nrow(data) >= 1000)
    g <- ggplot(data.melt, aes_string(x = vars.numeric[1], y = vars.numeric[2], fill = "value")) + stat_bin2d() + stat_smooth(colour="black", fill = "grey") + ggthemes::theme_hc() + facet_wrap(~variable) + scale_fill_manual(values = bering.colours) + bering.theme

  # Adjust scales
  if(max(data.melt[,vars.numeric[2]])/max(data.melt[,vars.numeric[1]])>=100)
    g <- g + scale_y_sqrt()
  if(max(data.melt[,vars.numeric[1]])/max(data.melt[,vars.numeric[2]])>=100)
    g <- g + scale_x_sqrt()

  # Export
  if(as.d3)
    g <- as.svg(g, ...)

#Histogram
} else if (class(object) == "d3.histogram"){
  data.melt <- reshape2::melt(data)
  g <- ggplot(data.melt, aes(x = value, fill = variable)) + geom_histogram(position="identity", alpha=0.5, bins = 50) + ylab("Frequency") + xlab("") + ggthemes::theme_hc() + bering.theme + scale_fill_manual(values = bering.colours)

  # Apply SQRT scaling to x and y axis if the data is large
  if( (max(data.melt[,"value"], na.rm = TRUE) - min(data.melt[,"value"], na.rm = TRUE)) > 1000 )
    g <- g + scale_x_sqrt()
  if( nrow(data) > 1000 )
    g <- g + scale_y_sqrt()

  if(as.d3)
    g <- as.svg(g, ...)

# Magic Plot :)
} else if (class(object) == "d3.magplot"){

  limits <- aes(ymax = mean + sd, ymin = mean)
  dodge <- position_dodge(width=0.9)

  g <- ggplot(data, aes_string(x = "var", y = "mean", fill = "var")) +  geom_errorbar(limits, position=dodge, width=0.25) + geom_bar(position = "dodge", stat="identity", color="black") + xlab("") + ylab("Average value") + ggthemes::theme_hc() + facet_wrap(reformulate(setdiff(vars.factor, "var")), labeller=label_both, ncol = 4) + theme(axis.text.x = element_text(angle = 45, hjust = 1)) + ggthemes::theme_hc() + bering.theme + scale_fill_manual(values = bering.colours)

  # Scale y axis only if there are multiple numerical vectors
  if(length(unique(data$var))>1){
    if( (max(data$mean + data$sd) - min(data$mean + data$sd)) > 1000 )
      g <- g + scale_y_sqrt()
  }

  if(as.d3)
    g <- as.svg(g, ...)

# Pie chart
} else if (class(object) == "d3.piechart"){
    data.melt <- reshape2::melt(table(data))
    colnames(data.melt) <- c("Factor", "value")

    g <- ggplot(data.melt, aes(x = "", y = value, fill = Factor)) + geom_bar(stat = "identity", width = 1)  + coord_polar(theta = "y", start = 0) + xlab("") + ylab("") + ggthemes::theme_hc() + scale_fill_manual(values = bering.colours) + bering.theme

    if(as.d3)
      g <- as.svg(g, ...)
} else{
  stop("Plot type is not supported yet.")
}
  return(g)
}
