library(bering.d3)
library(data.table)

symphony <- fread("/Users/ignat/Documents/Bering/Projects/BRAVE/Dataset/Symphony/symphony.csv")
setnames(symphony, old = colnames(symphony), new = gsub(x = colnames(symphony), pattern = "\\.", replacement = "_"))

vars <- c("Other_ALL_costs")
by <- c("Age", "pcdCancer")

object <- condense(vars, by, data = symphony)

d3.autoplot(object, as.d3 = F)

g <- d3.autoplot(object, as.d3 = T)
d3.write(g, "test.svg")
