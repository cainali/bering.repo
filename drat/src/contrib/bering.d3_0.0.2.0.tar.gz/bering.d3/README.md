Interactive R visualizations with D3 and ggplot2
=================================================
*bering.d3* is a new API for making beautiful graphics with **ggplot2** and **D3**.
The API allows to produce interactive plots using the standard R interface.

Getting started
-------------------------------------------------
Copy and paste the following code to install the necessary dependencies and the **bering.d3** package:

```r
if (! ("ggplot2" %in% rownames(installed.packages())) ) { install.packages("ggplot2") }
if (! ("XML" %in% rownames(installed.packages())) ) { install.packages("XML") }
if (! ("jsonlite" %in% rownames(installed.packages())) ) { install.packages("jsonlite") }
if (! ("data.table" %in% rownames(installed.packages())) ) { install.packages("data.table") }
if (! ("devtools" %in% rownames(installed.packages())) ) { install.packages("devtools") }

if (! ("bering.d3" %in% rownames(installed.packages())) ) { devtools::install_github("idroz/bering.d3") }
```

Simple interactive visualization
--------------------------------------------------

```r
library(bering.d3)
library(ggplot2)

set.seed(1000)
d <- diamonds[sample(nrow(diamonds), 1000), ]


g <- ggplot(data = d, aes_string(x = "carat", y = "price", col = "cut")) + geom_smooth() + geom_point()

obj <- d3.xyplot(g, zoom = TRUE, width = 8, height = 6)
d3.write(obj, "ggplot_2_d3.html")
```
 You can [view the generated figure as html](http://htmlpreview.github.com/?https://github.com/idroz/bering.d3/blob/master/ggplot_2_d3.html)
